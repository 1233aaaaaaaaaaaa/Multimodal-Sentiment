from lavis.models import load_model_and_preprocess
from PIL import Image
model, vis_processors, _ = load_model_and_preprocess(name="blip_feature_extractor", model_type="base", is_eval=True)
image = Image.open(r"C:\Users\18105\Desktop\图片测试\fy大头.jpg").convert('RGB')#读取图片
image = vis_processors["eval"](image).unsqueeze(0)
sample = {"image": image}
features_image = model.extract_features(sample, mode="image")
print(features_image.keys())
print(features_image.image_embeds.shape)
print(features_image.image_embeds_proj.shape)
import os
import re

from lavis.models import load_model_and_preprocess
from PIL import Image

# 加载模型
model, vis_processors, _ = load_model_and_preprocess(name="blip_feature_extractor", model_type="base", is_eval=True)

# 指定文件夹路径
folder_path = r"C:\Users\18105\Desktop\MVSA-Single\MVSA_Single\img"
def sort_by_number(filename):
    # 提取文件名中的数字部分
    match = re.search(r'\d+', filename)
    if match:
        return int(match.group())
    else:
        return -1
# 获取文件夹中的文件列表并按照顺序排序
file_list = sorted(os.listdir(folder_path), key=sort_by_number)

# 遍历文件夹中的所有png文件
for i in range(len(file_list)):
    if file_list[i].endswith(".jpg"):
        file_path = os.path.join(folder_path, file_list[i])

        # 读取图片
        image = Image.open(file_path).convert('RGB')
        image = vis_processors["eval"](image).unsqueeze(0)
        sample = {"image": image}

        # 提取特征并打印向量维度
        features_image = model.extract_features(sample, mode="image")
        print(f"文件: {file_list[i]}")
        print(f"Image Embeds 维度: {features_image.image_embeds.shape}")
        print(f"Image Embeds Proj 维度: {features_image.image_embeds_proj.shape}")
        print("------------------------")
# #对数据集图像数据所生成的文本数据进行编码
# import os
# import re
#
# from lavis.models import load_model_and_preprocess
# from PIL import Image
#
# # 加载图片描述生成模型和特征提取模型
# model_caption, vis_processors_caption, _ = load_model_and_preprocess(name="blip_caption", model_type="base_coco",
#                                                                      is_eval=True)
# model_feature, vis_processors_feature, txt_processors_feature = load_model_and_preprocess(name="blip_feature_extractor",
#                                                                                           model_type="base",
#                                                                                           is_eval=True)
# # 指定包含图片文件的文件夹路径
# folder_path = r"C:\Users\18105\Desktop\MVSA-Single\MVSA_Single\img"
# def sort_by_number(filename):
#     # 提取文件名中的数字部分
#     match = re.search(r'\d+', filename)
#     if match:
#         return int(match.group())
#     else:
#         return -1
# # 获取文件夹中的文件列表并按照顺序排序
# file_list = sorted(os.listdir(folder_path), key=sort_by_number)
#
# for i in range(len(file_list)):
#
#     file_path = os.path.join(folder_path, file_list[i])
#     if os.path.isfile(file_path) and file_list[i].lower().endswith('.jpg'):
#         # 读取图片
#         image = Image.open(file_path).convert('RGB')
#
#         # 对图片进行预处理，生成图片描述
#         image_processed = vis_processors_caption["eval"](image).unsqueeze(0)
#         caption = model_caption.generate({"image": image_processed})[0]
#
#         # 打印文字描述
#         print("图片文件:", file_list[i])
#         print("文字描述:", caption)
#
#         # 对文本描述进行预处理，编码为向量
#         text_input = txt_processors_feature["eval"](caption)
#         sample = {"text_input": [text_input]}
#         features_text = model_feature.extract_features(sample, mode="text")
#
#         # 打印文本向量的维度
#         print("文本向量的维度:", features_text.text_embeds_proj.shape)
#         print(features_text.text_embeds_proj)
#         print()

