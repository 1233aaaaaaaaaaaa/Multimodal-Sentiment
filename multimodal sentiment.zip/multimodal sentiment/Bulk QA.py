import os
from PIL import Image
from lavis.models import load_model_and_preprocess

# # 加载模型和预处理器
# model, vis_processors, txt_processors = load_model_and_preprocess(name="albef_vqa", model_type="vqav2", is_eval=True)
#
# # 定义要遍历的文件夹路径
# folder_path = r"C:\Users\18105\Desktop\Emotion6\images\Joy"
#
# # 询问问题
# question = "What emotions are contained in this picture?"
#
# # 创建情绪类别计数的字典
# emotion_counts = {'Joy': 0, 'Surprise': 0, 'Disgust': 0, 'Sadness': 0, 'Anger': 0, 'Fear': 0}
#
# # 遍历文件夹中的图片
# for filename in os.listdir(folder_path):
#     # 构建图片的完整路径
#     image_path = os.path.join(folder_path, filename)
#
#     # 加载图片
#     raw_image = Image.open(image_path).convert("RGB")
#
#     # 图片预处理
#     image = vis_processors["eval"](raw_image).unsqueeze(0)
#
#     # 问题预处理
#     processed_question = txt_processors["eval"](question)
#
#     # 生成回答
#     answers = model.predict_answers(samples={"image": image, "text_input": processed_question},
#                                     inference_method="generate", answer_list=['Joy', 'Surprise', 'Disgust', 'Sadness', 'Anger', 'Fear'])
#
#     # 遍历回答列表并更新情绪类别计数
#     for answer in answers:
#         emotion_counts[answer] += 1
#
#     # 打印图片文件名和回答
#     print("Image:", filename)
#     print("Answer:", answers)
#     print()
#
# # 打印每个情绪类别的数量
# print("Emotion Counts:")
# for emotion, count in emotion_counts.items():
#     print(emotion + ":", count)

import os
from PIL import Image
from lavis.models import load_model_and_preprocess
import re
# 加载模型和预处理器
model, vis_processors, txt_processors = load_model_and_preprocess(name="blip_vqa", model_type="vqav2", is_eval=True)

# 定义要遍历的文件夹路径
folder_path = r"C:\Users\18105\Desktop\MVSA-multiple\MVSA\img"

# 询问问题
question = "Do you think the emotions in the picture are positive, negative or neutral?"

# 创建结果保存的文件
output_file = open("emotion_results.txt", "w")

# 自定义排序函数，按照文件名的数字顺序排序
def sort_by_number(filename):
    # 提取文件名中的数字部分
    match = re.search(r'\d+', filename)
    if match:
        return int(match.group())
    else:
        return -1

# 获取文件夹中的文件列表并按照顺序排序
file_list = sorted(os.listdir(folder_path), key=sort_by_number)

# 遍历文件夹中的文件
for i in range(len(file_list)):
    # 构建文件的完整路径
    file_path = os.path.join(folder_path, file_list[i])

    # 检查是否为图片文件
    if file_list[i].lower().endswith((".jpg", ".jpeg", ".png", ".gif")):
        # 加载图片
        raw_image = Image.open(file_path).convert("RGB")

        # 图片预处理
        image = vis_processors["eval"](raw_image).unsqueeze(0)

        # 问题预处理
        processed_question = txt_processors["eval"](question)

        # 生成回答
        answers = model.predict_answers(samples={"image": image, "text_input": processed_question}, inference_method="generate")

        # 打印文件名和生成的答案
        print("File:", file_list[i])
        print("Answer:", answers)
        print()

        # 将文件名和生成的答案写入文件
        output_file.write("File: " + file_list[i] + "\n")
        output_file.write("Answer: " + str(answers) + "\n")
        output_file.write("\n")

# 关闭文件
output_file.close()