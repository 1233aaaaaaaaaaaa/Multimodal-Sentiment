import os
import torch
import torch.optim as optim
import torch.nn.functional as F
import torch.nn as nn

file_path = r"/home/u202220081200020/biaoqian.txt"

# 读取标签数据
tensor_list = []
with open(file_path, 'r') as file:
    lines = file.readlines()
    for line in lines:
        line = line.strip()
        numbers = line.split()
        tensor = torch.tensor([float(num) for num in numbers])
        tensor_list.append(tensor)

class Attention(nn.Module):
    def __init__(self, input_size):
        super(Attention, self).__init__()
        self.input_size = input_size

    def forward(self, x):
        attention_weights = torch.matmul(x, x.transpose(1, 2))
        attention_weights = F.softmax(attention_weights, dim=2)
        weighted_input = torch.matmul(attention_weights, x).squeeze(1)
        return weighted_input


class MyNetwork(nn.Module):
    def __init__(self):
        super(MyNetwork, self).__init__()
        self.flatten = nn.Flatten()
        self.dropout1 = nn.Dropout(0.9)
        self.attention = Attention(86784)
        self.fc = nn.Linear(86784, 3)

    def forward(self, x):
        x = self.flatten(x)
        x = self.dropout1(x)
        x = x.view(-1, 1, self.attention.input_size)
        x = self.attention(x)
        x = self.fc(x)
        return x

# 检查是否有可用的GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
network = MyNetwork().to(device)

# 指定pt文件的路径和训练数据
pt_file_path = r'/home/u202220081200020/expanded1.pt'
data = torch.load(pt_file_path)

# 将数据转换为张量
input_tensors = [torch.tensor(tensor) for tensor in data]
tensor_list = [tensor.to(device) for tensor in tensor_list]
train_tensors = input_tensors[0:4300]
val_tensors = input_tensors[4300:4450]
test_tensors = input_tensors[4450:]

# 将训练和验证数据移动到对应设备
train_tensors = [tensor.to(device) for tensor in train_tensors]
val_tensors = [tensor.to(device) for tensor in val_tensors]
test_tensors = [tensor.to(device) for tensor in test_tensors]
# 自定义损失函数
def custom_loss(output, lable):
    target_similarity = F.cosine_similarity(output , lable, dim=1)
    all_list = [torch.tensor([1, 0, 0]), torch.tensor([0, 1, 0]), torch.tensor([0, 0, 1])]
    all_list = [tensor.to(device) for tensor in all_list]
    other_loss_similartiy = []
    for label_tensor in all_list:
        if not torch.all(torch.eq(lable, label_tensor)):
            similarity = F.cosine_similarity(output, label_tensor, dim=1)
            other_loss_similartiy.append(similarity)
    max_similarity_other = torch.max(torch.stack(other_loss_similartiy))
    diff = target_similarity - max_similarity_other
    # loss = -torch.log((1 + diff) / 2)#t梯度爆炸了
    # loss = 1 - F.leaky_relu(diff, negative_slope=0.1)  # 使用Leaky ReLU激活函数
    diff = torch.sigmoid(10 * diff) * 2 - 1  # 使用sigmoid函数将diff从-1到1映射，缩放因子
    loss = 1 - diff
    return loss

# 定义优化器
optimizer = optim.AdamW(network.parameters(), lr=0.0005, weight_decay=0.1)
os.makedirs("weights", exist_ok=True)
num_epochs = 200
best_val_accuracy = 0.0  # 保存最佳的验证集准确率
best_model_weights = None  # 保存最佳的模型参数
for epoch in range(num_epochs):
    train_running_loss = 0.0
    train_correct_total = 0
    train_total = 0

    # 训练阶段
    network.train()

    for i, input_tensor in enumerate(train_tensors):
        optimizer.zero_grad()

        output = network(input_tensor)

        loss = custom_loss(output, tensor_list[i])

        loss.backward()
        torch.nn.utils.clip_grad_norm_(network.parameters(), max_norm=1.0)
        optimizer.step()

        # 统计准确率
        target_similarity = F.cosine_similarity(output, tensor_list[i], dim=1)
        label_list = [torch.tensor([1, 0, 0]), torch.tensor([0, 1, 0]), torch.tensor([0, 0, 1])]
        label_list = [tensor.to(device) for tensor in label_list]
        other_list = []
        for label_tensor in label_list:
            if not torch.all(torch.eq(tensor_list[i], label_tensor)):
                other_list.append(label_tensor)

        if target_similarity > torch.max(torch.stack([F.cosine_similarity(output, other, dim=1) for other in other_list]), dim=0).values:
            train_correct_total += 1

        train_total += 1

        train_running_loss += loss.item()

    # 计算训练集的准确率和损失
    train_accuracy = train_correct_total / train_total
    train_loss = train_running_loss / len(train_tensors)

    # 保存网络参数
    if epoch == num_epochs - 1:
        torch.save(network.state_dict(), 'weights/final_model.pt')
    torch.save(network.state_dict(), f'weights/model_epoch_{epoch + 1}.pt')

    # 打印训练集的准确率和损失
    print('Train Accuracy: %.2f%%' % (100 * train_accuracy))
    print('Epoch: %d, Train Loss: %.3f' % (epoch + 1, train_loss))

    network.eval()
    val_correct_total = 0
    val_total = 0
    val_running_loss = 0.0

    with torch.no_grad():
        for j, val_input_tensor in enumerate(val_tensors):
            val_output = network(val_input_tensor)

            label_list = [torch.tensor([1, 0, 0]), torch.tensor([0, 1, 0]), torch.tensor([0, 0, 1])]
            label_list = [tensor.to(device) for tensor in label_list]
            other_list1 = []
            val_target_similarity = F.cosine_similarity(val_output, tensor_list[j+4300], dim=1)
            for label_tensor in label_list:
                if not torch.all(torch.eq(tensor_list[j+4300], label_tensor)):
                    other_list1.append(label_tensor)

            if val_target_similarity > torch.max(torch.stack([F.cosine_similarity(val_output, other, dim=1) for other in other_list1]), dim=0).values:
                val_correct_total += 1

            val_total += 1

            loss = custom_loss(val_output, tensor_list[j+4300])
            val_running_loss += loss.item()

        # 计算验证集的准确率和损失
        val_accuracy = val_correct_total / val_total
        val_loss = val_running_loss / len(val_tensors)
        # 保存最佳模型
        if val_accuracy > best_val_accuracy:
            best_val_accuracy = val_accuracy
            best_model_weights = network.state_dict()

        # 打印验证集的准确率和损失
        print('Validation Accuracy: %.2f%%' % (100 * val_accuracy))
        print('Epoch: %d, Validation Loss: %.3f' % (epoch + 1, val_loss))
# torch.save(best_model_weights, 'best_model.pt')
# 加载保存的网络参数
# network = MyNetwork()
# network.load_state_dict(torch.load(r'/home/u202220081200020/jupyterlab/Untitled Folder/weights/model_epoch_47.pt'))
# # 在测试集上计算准确率
# network.eval()
# total = 0
# correct_total = 0
# with torch.no_grad():
#     for k, test_input_tensor in enumerate(test_tensors):
#         output = network(test_input_tensor)
#         target_similarity = F.cosine_similarity(output, tensor_list[k+4450], dim=1)
#         label_list = [torch.tensor([1, 0, 0]), torch.tensor([0, 1, 0]), torch.tensor([0, 0, 1])]
#         label_list = [tensor.to(device) for tensor in label_list]
#         other_list2 = []
#         for label_tensor in label_list:
#             if not torch.all(torch.eq(tensor_list[k+4450], label_tensor)):
#                 other_list2.append(label_tensor)

#         if target_similarity > torch.max(torch.stack([F.cosine_similarity(output, other.unsqueeze(0), dim=1) for other in other_list2]), dim=0).values:
#             correct_total += 1

#         total += 1

# # 计算准确率
# accuracy = correct_total / total

# # 打印准确率
# print('Accuracy: %.2f%%' % (accuracy * 100))

# 初始化真阳性（TP）、假阳性（FP）和假阴性（FN）的计数
# tp = 0
# fp = 0
# fn = 0

# # 在测试集上计算准确率和 F1 分数
# with torch.no_grad():
#     for k, test_input_tensor in enumerate(test_tensors):
#         output = network(test_input_tensor)
#         target_similarity = F.cosine_similarity(output, tensor_list[k + 4450], dim=1)

#         label_list = [torch.tensor([1, 0, 0]), torch.tensor([0, 1, 0]), torch.tensor([0, 0, 1])]
#         other_list2 = []
#         for label_tensor in label_list:
#             if not torch.all(torch.eq(tensor_list[k + 4450], label_tensor)):
#                 other_list2.append(label_tensor)

#         max_similarity = torch.max(
#             torch.stack([F.cosine_similarity(output, other.unsqueeze(0), dim=1) for other in other_list2]))
#         #[1,0,0]为标签
#         if torch.all(torch.eq(tensor_list[k + 4450], torch.tensor([1, 0, 0]))) and F.cosine_similarity(output,torch.tensor([1, 0, 0])) > max(F.cosine_similarity(output,torch.tensor([0 ,1, 0])),F.cosine_similarity(output,torch.tensor([0 ,0, 1]))):
#             tp += 1
#         elif torch.all(
#                 torch.eq(tensor_list[k + 4450], torch.tensor([1, 0, 0]))) and F.cosine_similarity(output,torch.tensor([1, 0, 0])) <= max(F.cosine_similarity(output,torch.tensor([0 ,1, 0])),F.cosine_similarity(output,torch.tensor([0 ,0, 1]))):
#             fn += 1
#         elif not torch.all(
#                 torch.eq(tensor_list[k + 4450], torch.tensor([1, 0, 0]))) and F.cosine_similarity(output,torch.tensor([1, 0, 0])) > max(F.cosine_similarity(output,torch.tensor([0 ,1, 0])),F.cosine_similarity(output,torch.tensor([0 ,0, 1]))):
#             fp += 1
#         if torch.all(torch.eq(tensor_list[k + 4450], torch.tensor([0, 1, 0]))) and F.cosine_similarity(output, torch.tensor(
#             [0, 1, 0])) > max(F.cosine_similarity(output, torch.tensor([0, 0, 1])),
#                               F.cosine_similarity(output, torch.tensor([1, 0, 0]))):
#             tp += 1
#         elif torch.all(
#                 torch.eq(tensor_list[k + 4450], torch.tensor([0, 1, 0]))) and F.cosine_similarity(output, torch.tensor(
#             [0, 1, 0])) <= max(F.cosine_similarity(output, torch.tensor([0, 0, 1])),
#                               F.cosine_similarity(output, torch.tensor([1, 0, 0]))):
#             fn += 1
#         if not torch.all(
#                 torch.eq(tensor_list[k + 4450], torch.tensor([0, 1, 0]))) and F.cosine_similarity(output, torch.tensor(
#             [0, 1, 0])) > max(F.cosine_similarity(output, torch.tensor([0, 0, 1])),
#                               F.cosine_similarity(output, torch.tensor([1, 0, 0]))):
#             fp += 1
#         if torch.all(torch.eq(tensor_list[k + 4450], torch.tensor([0, 0, 1]))) and  F.cosine_similarity(output, torch.tensor(
#             [0, 0, 1])) > max(F.cosine_similarity(output, torch.tensor([0, 1, 0])),
#                               F.cosine_similarity(output, torch.tensor([1, 0, 0]))):
#             tp += 1
#         elif torch.all(
#                 torch.eq(tensor_list[k + 4450], torch.tensor([0, 0, 1]))) and  F.cosine_similarity(output, torch.tensor(
#             [0, 0, 1])) <= max(F.cosine_similarity(output, torch.tensor([0, 1, 0])),
#                               F.cosine_similarity(output, torch.tensor([1, 0, 0]))):
#             fn += 1
#         elif not torch.all(
#                 torch.eq(tensor_list[k + 4450], torch.tensor([0, 0, 1]))) and F.cosine_similarity(output, torch.tensor(
#             [0, 0, 1])) > max(F.cosine_similarity(output, torch.tensor([0, 1, 0])),
#                               F.cosine_similarity(output, torch.tensor([1, 0, 0]))):
#             fp += 1


# # 计算精确率和召回率
# print(tp)
# print(fp)
# print(fn)
# precision = tp / (tp + fp)
# recall = tp / (tp + fn)

# # 计算 F1 分数
# f1_score = 2 * (precision * recall) / (precision + recall)

# # 打印精确率、召回率和 F1 分数
# print('Precision: %.2f%%' % (precision * 100))
# print('Recall: %.2f%%' % (recall * 100))
# print('F1 Score: %.2f%%' % (f1_score * 100))
