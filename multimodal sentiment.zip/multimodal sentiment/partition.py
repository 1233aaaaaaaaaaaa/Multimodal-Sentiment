import os
import shutil

# 源文件夹路径
source_folder = r"C:\Users\18105\Desktop\archive\MVSA\data"

# 目标文件夹路径
jpg_folder = r"C:\Users\18105\Desktop\archive\MVSA\img"
txt_folder = r"C:\Users\18105\Desktop\archive\MVSA\txt"

# 创建目标文件夹
os.makedirs(jpg_folder, exist_ok=True)
os.makedirs(txt_folder, exist_ok=True)

# 遍历源文件夹中的文件
for filename in os.listdir(source_folder):
    file_path = os.path.join(source_folder, filename)
    if os.path.isfile(file_path):
        # 判断文件类型并分类
        if filename.lower().endswith(".jpg"):
            shutil.move(file_path, os.path.join(jpg_folder, filename))
            print(f"Moved {filename} to {jpg_folder}")
        elif filename.lower().endswith(".txt"):
            shutil.move(file_path, os.path.join(txt_folder, filename))
            print(f"Moved {filename} to {txt_folder}")
        else:
            print(f"Ignored {filename}")

print("分类完成！")
