import os
import torch
import torchvision
import numpy as np

concatenated_features_list = torch.load('concatenated_features.pt')

# 创建保存图像的文件夹
os.makedirs('images', exist_ok=True)

for i, concatenated_features in enumerate(concatenated_features_list):
    # 扩展第一个维度为3
    concatenated_features = concatenated_features.expand(3, -1, -1)
    # 将第一个维度扭到最后面
    concatenated_features = concatenated_features.permute(1, 2, 0)
    # 加上0.5并乘以255
    concatenated_features = (concatenated_features + 0.5) * 255
    # 转换为numpy数组
    concatenated_features_np = concatenated_features.numpy().astype(np.uint8)
    # 创建PIL图像对象
    image = torchvision.transforms.functional.to_pil_image(concatenated_features_np)
    # 保存为PNG图像
    image_path = os.path.join('images', f'image_{i+1}.png')
    image.save(image_path)