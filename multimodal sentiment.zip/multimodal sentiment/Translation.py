import os
import string

import requests
from lavis.models import load_model_and_preprocess
from PIL import Image
from nltk.tokenize import word_tokenize

# 加载模型
model, vis_processors, _ = load_model_and_preprocess(name="blip_caption", model_type="base_coco", is_eval=True)

# 待处理的文件夹
folder_path = r"C:\Users\18105\Desktop\图片测试"

# 存储所有图片的翻译结果
all_desc = []

# 遍历文件夹内的所有图片
for filename in os.listdir(folder_path):
    if filename.endswith(".jpg") or filename.endswith(".jpeg") or filename.endswith(".png"):
        # 打开图片，转换为 RGB 格式，进行预处理
        image_path = os.path.join(folder_path, filename)
        image = Image.open(image_path).convert('RGB')
        image = vis_processors["eval"](image).unsqueeze(0)

        # 生成描述并打印结果
        result = model.generate({"image": image})
        print(f"{filename}: {result}")

        # 去除标点符号
        tokens = word_tokenize(str(result))
        zh_desc = []
        for token in tokens:
            # 去除标点符号
            token = token.translate(str.maketrans("", "", string.punctuation))
            if token:
                API = 'http://fanyi.youdao.com/translate?&doctype=json&type=AUTO&i='
                API返回的数据 = requests.get(f'{API}{token}').json()
                翻译结果 = API返回的数据['translateResult'][0][0]['tgt']
                zh_desc.append(翻译结果)
        all_desc.append(zh_desc)
        print(f"翻译结果：{zh_desc}")

print(f"所有图片的翻译结果：{all_desc}")







