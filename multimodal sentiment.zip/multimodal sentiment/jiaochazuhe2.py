# -*- coding : utf-8-*-
import os
import re
from lavis.models import load_model_and_preprocess
from PIL import Image
import jieba
import torch
import numpy as np
import gzip
#加载图片描述生成模型和特征提取模型
model_caption, vis_processors_caption, _ = load_model_and_preprocess(name="blip_caption", model_type="base_coco", is_eval=True)
model_feature, vis_processors_feature, txt_processors_feature = load_model_and_preprocess(name="blip_feature_extractor", model_type="base", is_eval=True)

# 指定包含图片文件的文件夹路径和包含文本文件的文件夹路径
img_folder_path = r"/home/u202220081200020/交叉组合专用/MVSA-Single-img"
txt_folder_path = r"/home/u202220081200020/交叉组合专用/txt"

def sort_by_number(filename):
    # 提取文件名中的数字部分
    match = re.search(r'\d+', filename)
    if match:
        return int(match.group())
    else:
        return -1

# 获取图片文件夹中的文件列表并按照顺序排序
img_file_list = sorted(os.listdir(img_folder_path), key=sort_by_number)

# 获取文本文件夹中的文件列表并按照顺序排序
txt_file_list = sorted(os.listdir(txt_folder_path), key=sort_by_number)
#加载停用词表
stopwords_file_path = './stopwords.txt'
#读取停用词表
with open(stopwords_file_path, 'r', encoding='utf-8') as stopwords_file:
    stopwords = stopwords_file.read().splitlines()

# 遍历图片文件夹和文本文件夹
for i in range(len(img_file_list)):
    img_file_path = os.path.join(img_folder_path, img_file_list[i])
    txt_file_path = os.path.join(txt_folder_path, txt_file_list[i])

    if os.path.isfile(img_file_path) and img_file_list[i].lower().endswith('.jpg') and os.path.isfile(txt_file_path) and txt_file_list[i].lower().endswith('.txt'):
        # 读取文本文件并进行编码和分词
        with open(txt_file_path, 'r', encoding='utf-8',errors='ignore') as file:
            text = file.read().strip()
            #清除掉@后面出现的人名
            text = re.sub(r'@\w+', '', text)
            #只保留英文单词，并去除特殊字符和空格
            text = re.sub(r'[^\w\s]|[^a-zA-Z\s]', '', text)
            # # 清洗文本，去除特殊字符和空格
            # text = re.sub(r'[^\w\s]', '', text)
            text = ' '.join([word for word in text.split() if word.lower() not in stopwords])
        # 分词
        seg_list = list(filter(lambda x: x.strip(), jieba.cut(text, cut_all=False)))  # 转换为列表并去除空格
        seg_result = " ".join(seg_list)
        print(f"分词结果：{seg_result}")
        print(seg_list)
        # 对分词结果进行编码
        encoded_words  = [] #新建一个列表
        for word in seg_list: #循环处理分词结果，分别对它们进行编码，编码结果存储到encoded_words中
            text_input = txt_processors_feature["eval"](word)
            sample = {"text_input": [text_input]}
            text_input = model_feature.extract_features(sample, mode="text")
            encoded_words.append(text_input.text_embeds_proj)


        # 存储编码结果
        globals()[f"txt_list{i+1}"] = encoded_words

       # 生成图片描述并进行分词和编码
        image = Image.open(img_file_path).convert('RGB')
        image_processed = vis_processors_caption["eval"](image).unsqueeze(0)
        caption = model_caption.generate({"image": image_processed})[0]
        # 清洗文本，去除特殊字符和空格
        caption = re.sub(r'[^\w\s]', ' ', caption)
        #去除停用词
        caption = ' '.join([word for word in caption.split() if word.lower() not in stopwords])
        # 分词
        seg_list = list(filter(lambda x: x.strip(), jieba.cut(caption, cut_all=False)))  # 转换为列表并去除空格
        seg_result = " ".join(seg_list)
        print(f"图片描述分词结果：{seg_result}")
        print(seg_list)

        # 对分词结果进行编码
        encoded_words = []
        for word in seg_list:
            text_input = txt_processors_feature["eval"](word)
            sample = {"text_input": [text_input]}
            text_input = model_feature.extract_features(sample, mode="text")
            encoded_words.append(text_input.text_embeds_proj)

        # 存储编码结果
        globals()[f"img_txt_list{i + 1}"] = encoded_words

import pickle

# 保存全局变量到文件
def save_global_variable(var, filename):
    with open(filename, 'wb') as f:
        pickle.dump(var, f)

# 从文件中加载全局变量
def load_global_variable(filename):
    with open(filename, 'rb') as f:
        var = pickle.load(f)
    return var

# 保存所有的列表到文件
word_lists = {
    "txt_lists": [globals()[f"txt_list{i}"] for i in range(1, len(img_file_list) + 1)],
    "img_txt_lists": [globals()[f"img_txt_list{i}"] for i in range(1, len(img_file_list) + 1)]
}

save_global_variable(word_lists, 'word_lists1.pkl')
# 从文件中加载全局变量
word_lists1 = load_global_variable('word_lists1.pkl')

# 载入所有的列表
txt_lists = word_lists1["txt_lists"]
img_txt_lists = word_lists1["img_txt_lists"]
print(img_txt_lists[0][0].shape)


# 交叉组合
import pickle
import gzip
import torch


# 加载保存的列表。读取pkl文件，生成三个列表
def load_data(filename):
    with open(filename, 'rb') as file:
        data = pickle.load(file)
    return data


# 从文件中加载数据
word_lists = load_data('word_lists1.pkl')
# print(word_lists["txt_lists"][4000][3].shape)
# img_lists = load_data('img_lists.pt.gz')
# print(img_lists[0][0].shape)
input_filename = 'img_lists.pt.gz'
with gzip.open(input_filename, 'rb') as f:
    img_lists = torch.load(f)
# print(img_lists[4000][0].shape)


import torch

# 创建一个空列表来存储拼接后的矩阵
concatenated_matrices = []

# 遍历img_lists、word_lists["txt_lists"]和word_lists["img_txt_lists"]，第一个循环，先取出第一，二，三个列表的对应图片的子列表
# for i in range(len(img_lists)):
for i in range(1000):
    print(i)
    img_tensor_list = img_lists[i]  # 这张图片对应目标检测出来的区域中所有编码集合
    txt_tensor_list = word_lists["txt_lists"][i]  # 这张图片对应文本分词过后所有词语的编码集合
    img_txt_tensor_list = word_lists["img_txt_lists"][i]  # 这张图片所有图片生成文本的分词结果对应编码集合
    # 检查有没有空的列表，有的话就跳出此次循环
    if not img_tensor_list or not txt_tensor_list or not img_txt_tensor_list:
        continue
    # 确定当前图片的子列表长度
    img_length = len(img_tensor_list)  # 该图片目标检测的区域个数
    txt_length = len(txt_tensor_list)  # 文本分词个数
    img_txt_length = len(img_txt_tensor_list)  # 图片生成文本分词个数

    # 创建一个空列表来存储当前组合的拼接结果
    combined_tensors = []

    # 遍历每个组合的张量
    for j in range(img_length):
        for k in range(txt_length):
            for l in range(img_txt_length):
                # 提取对应位置的张量
                img_tensor = img_tensor_list[j]
                txt_tensor = txt_tensor_list[k]
                img_txt_tensor = img_txt_tensor_list[l]
                # 进行纵向拼接，列的方向
                concatenated_tensor = torch.cat((img_tensor, txt_tensor, img_txt_tensor), dim=1)
                combined_tensors.append(concatenated_tensor)

    # 将当前组合的拼接结果进行纵向拼接
    concatenated_matrix = torch.cat(combined_tensors, dim=1)
    concatenated_matrices.append(concatenated_matrix)
# 测试代码
print(concatenated_matrices[2].shape)
output_filename = 'concatenated_matrices_list.pt.gz'
with gzip.open(output_filename, 'wb') as f:
    torch.save(concatenated_matrices, f)
input_filename = 'concatenated_matrices_list.pt.gz'
with gzip.open(input_filename, 'rb') as f:
    concatenated_matrices_list = torch.load(f)
# 测试代码
print(concatenated_matrices_list[0].shape)
print(concatenated_matrices_list[1].shape)

# 将所有维度全部填充成最大值，并且再存储为pt文件。。。。
# 找出最大的第二个维度的值是多少
max_x = max(matrix.shape[1] for matrix in concatenated_matrices_list)
# 遍历所有矩阵，进行填充,为了减少影响全填充0
for i in range(len(concatenated_matrices_list)):
    matrix = concatenated_matrices_list[i]  # 找到第i个矩阵
    x = matrix.shape[1]  # 取出第二个需要填充的维度
    if x < max_x:  # 判断是否为最大值
        padding = torch.zeros((1, max_x - x, 256))  # 其余维度全部填充0
        padded_matrix = torch.cat((matrix, padding), dim=1)  # 沿第二个维度连接矩阵和填充张量
        concatenated_matrices_list[i] = padded_matrix  # 将填充后的矩阵赋值回列表
        print(concatenated_matrices_list[i].shape)  # 打印填充后的矩阵的形状
# 看看第二个维度最大的是多大
print("%^%^%^%^%^%^%^%^%^")
print(concatenated_matrices_list[1].shape)
# 存储填充后的concatenated_matrices为.pt文件
output_filename = 'concatenated_matrices.pt'
with gzip.open(output_filename, 'wb') as f:
    torch.save(concatenated_matrices_list, f)
input_filename = 'concatenated_matrices.pt'
with gzip.open(input_filename, 'rb') as f:
    concatenated_matrices_list1 = torch.load(f)
print("!@!@!@!@!@!@!@")
print(concatenated_matrices_list1[0].shape)
print(concatenated_matrices_list1[1].shape)

# output_filename = 'concatenated_matrices_list.pt.gz'
# with gzip.open(output_filename, 'wb') as f:
#     torch.save(concatenated_matrices, f)
# input_filename = 'concatenated_matrices_list.pt.gz'
# with gzip.open(input_filename,'rb') as f:
#     concatenated_matrices_list = torch.load(f)
# #测试代码
# print(concatenated_matrices_list[0].shape)
# print(concatenated_matrices_list[1].shape)