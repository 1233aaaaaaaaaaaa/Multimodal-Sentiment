# 使用文件地址打开第一个txt文件以读取内容
file1_path = r"C:\Users\18105\Desktop\MVSA-multiple\MVSA\emotion_results.txt"  # 替换为第一个txt文件的地址
with open(file1_path, 'r') as file1:
    lines = file1.readlines()

# 初始化用于记录词语的列表
words = []

# 遍历第一个txt文件的每一行
for line in lines:
    line = line.strip()  # 去除行末的换行符或空格
    if 'positive' in line:
        words.append('positive')
    elif 'negative' in line:
        words.append('negative')
    elif 'neutral' in line:
        words.append('neutral')

# 使用文件地址打开第二个txt文件以追加内容
file2_path = r"C:\Users\18105\Desktop\MVSA-multiple\MVSA\labelResultAll - 副本.txt"  # 替换为第二个txt文件的地址
with open(file2_path, 'r') as file2:
    file2_lines = file2.readlines()

# 使用文件地址打开第二个txt文件以写入内容
with open(file2_path, 'w') as file2:
    # 遍历第二个txt文件的每一行
    for i in range(len(file2_lines)):
        line = file2_lines[i].strip()  # 去除行末的换行符或空格
        word_index = i % len(words)  # 循环获取词语的索引
        word = words[word_index]

        # 将词语添加到每一行的行末
        file2.write(f"{line} {word}\n")

    # 如果第二个txt文件的行数多于词语的个数，继续追加词语
    for j in range(len(file2_lines), len(words)):
        word = words[j]
        file2.write(f"{word}\n")
