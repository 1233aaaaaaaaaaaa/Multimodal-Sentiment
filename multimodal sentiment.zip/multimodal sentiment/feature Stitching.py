import os
import re
from lavis.models import load_model_and_preprocess
from PIL import Image

# 加载图片描述生成模型和特征提取模型
model_caption, vis_processors_caption, _ = load_model_and_preprocess(name="blip_caption", model_type="base_coco", is_eval=True)
model_feature, vis_processors_feature, txt_processors_feature = load_model_and_preprocess(name="blip_feature_extractor", model_type="base", is_eval=True)

# 指定包含图片文件的文件夹路径和包含文本文件的文件夹路径
img_folder_path = r"C:\Users\18105\Desktop\MVSA-Single\MVSA_Single\img"
txt_folder_path = r"C:\Users\18105\Desktop\MVSA-Single\MVSA_Single\txt"

def sort_by_number(filename):
    # 提取文件名中的数字部分
    match = re.search(r'\d+', filename)
    if match:
        return int(match.group())
    else:
        return -1

# 获取图片文件夹中的文件列表并按照顺序排序
img_file_list = sorted(os.listdir(img_folder_path), key=sort_by_number)

# 获取文本文件夹中的文件列表并按照顺序排序
txt_file_list = sorted(os.listdir(txt_folder_path), key=sort_by_number)

# 遍历图片文件夹和文本文件夹
for i in range(len(img_file_list)):
    img_file_path = os.path.join(img_folder_path, img_file_list[i])
    txt_file_path = os.path.join(txt_folder_path, txt_file_list[i])

    if os.path.isfile(img_file_path) and img_file_list[i].lower().endswith('.jpg') and os.path.isfile(txt_file_path) and txt_file_list[i].lower().endswith('.txt'):
        # 读取图片
        image = Image.open(img_file_path).convert('RGB')

        # 对图片进行预处理，生成图片描述
        image_processed = vis_processors_caption["eval"](image).unsqueeze(0)
        caption = model_caption.generate({"image": image_processed})[0]

        # 打印图片文件名和对应的文字描述
        print("图片文件:", img_file_list[i])
        print("文字描述:", caption)

        # 对图片描述进行预处理，编码为向量
        text_input = txt_processors_feature["eval"](caption)
        sample = {"text_input": [text_input]}
        features_text = model_feature.extract_features(sample, mode="text")

        # 打印文本向量的维度
        print("文本向量的维度:", features_text.text_embeds_proj.shape)

        # 提取图片特征并打印向量维度
        image_processed = vis_processors_feature["eval"](image).unsqueeze(0)
        features_image = model_feature.extract_features({"image": image_processed}, mode="image")

        # 打印图片的proj维度
        print("图片的proj维度:", features_image.image_embeds_proj.shape)

        # 读取文本文件并进行编码
        with open(txt_file_path, 'r') as file:
            text = file.read().strip()

        text_input = txt_processors_feature["eval"](text)
        sample = {"text_input": [text_input]}
        features_text_file = model_feature.extract_features(sample, mode="text")

        # 打印文本文件的向量维度
        print("文本文件向量的维度:", features_text_file.text_embeds_proj.shape)

        print()
